//Totalistic Cellular Automaton
//Student:Ana Kelmendi
//Class: CS 211
//Proffesor: Scott Reckinger
//Project starts by asking teh user to enter a rule number, then it asks the number of generations where the cells should evolve,
//...and then it asks to enter the value for the initial active cell. After this the program runs it shows the user how the cells change every time, and shows how active every singel cell is.


#include <stdio.h>
#include <stdbool.h>

const int WORLD_SIZE = 65;

typedef struct cell_struct{
    int localSum; // total sum of local cells, [left] + [me] + [right]: possible values are 0-6
    int status;   // this cell's current status: 0, 1, or 2
    int count;    // running accumulated count of this cell's active status for all generations
} cell;



//TASK 1- Converts the input integer rule to its ternary
bool setValArray(int valArray[7], int rule) {

//Will return T if the rule is (0-2186)
    if (rule < 0 || rule > 2186){
        return false;
}

    for (int i=0; i<7; i++){
            valArray[i]= rule % 3;
            rule/=3;
        }
        return true;
    }


//TASK 2 - generate the rule's 7-ternary-digit status/contents of the value array
void printValueArr(int valArray[7]){
    printf("Value array is; ");

    for (int i=6; i>=0; i--){
        printf("%d", valArray[i]);
    }
    printf("\n");
}


//TASK 3- shows the evolution steps for all possible cell states
void printEvolutionOfStates(int valArray[7]){


//This is what was given to us to hardcode
    printf("The evolution of all possible states are as follows:\n");

    printf("Local Sum:   6       5       4       3       2       1       0      \n");
    printf("States:    |+++|   |++-|   |++ |   |+- |   |-- |   |-  |   |   |    \n");
    printf("                   |+-+|   |+ +|   |+ -|   |- -|   | - |            \n");
    printf("                   |-++|   | ++|   |-+ |   | --|   |  -|            \n");
    printf("                           |+--|   | +-|   |+  |                    \n");
    printf("                           |-+-|   |- +|   | + |                    \n");
    printf("                           |--+|   | -+|   |  +|                    \n");
    printf("                                   |---|                            \n");

//This prints the new status, and sees weather it's active, inactive, or less active.
    printf("New Status: ");

    for (int i=6; i >=0; i--){
        if (valArray[i] ==2)
            printf("|+|     ");
        else if(valArray[i] ==1)
            printf("|-|     ");
        else
            printf("| |     ");
    }
    printf("\n\n");
}


//TASK 4- updates the localSum subitem for each cell in the world
void setSums(cell world[WORLD_SIZE]) {

    for (int i=0; i<WORLD_SIZE; i++){
        int left = (i==0) ? WORLD_SIZE - 1: i-1;
        int right = (i == WORLD_SIZE - 1) ? 0 : i + 1;

        world[i].localSum = world[left].status + world[i].status + world[right].status;
    }
    return;
}


//TASK 6- evolves each cell's status value to the next generation using its localSum subitem
int evolveWorld(cell world[WORLD_SIZE], int ruleValArray[7]) {
    int updatedStatus[WORLD_SIZE];
    int totalsum=0;

//Updates the statues of every single cell
    for (int i=0; i<WORLD_SIZE; i++){
        updatedStatus[i] = ruleValArray[world[i].localSum];
    }

    for (int i=0; i<WORLD_SIZE; i++){
        world[i].status = updatedStatus[i];
        world[i].count += updatedStatus[i];
    }

    setSums(world);
    return 0;
}


int main() {
    cell world[WORLD_SIZE];
    int rule;
    int valArray[7];
    int numOfgen;
    int initialState;

    printf("Welcome to the Totalistic Cellular Automaton!\n");

//Looks at rule numbers
    do{
        printf("Enter the rule # (0-2186): \n");
        scanf("%d", &rule);
    }while(!setValArray (valArray, rule));

    printf("\n");

    printf("The value array for rule #%d is ", rule);
    for (int i=6; i>=0; i--){
        printf("%d", valArray[i]);
    }
    printf("\n\n");
    //


    printEvolutionOfStates(valArray);
    setSums(world);

    //TODO: Task 5a - read in the total number of generation evolution steps
    //      from the user, allowing repeated attempts for invalid values.
    //      Follow the format, including whitespaces, of the sample output EXACTLY.
    do{
        printf("Enter the number of generations (1-49): "); 
        printf("\n");
        scanf("%d", &numOfgen);
    } while (numOfgen < 1 || numOfgen > 49);

    
    //TODO: Task 5b - read in the initial status value for the middle cell, 
    //      allowing repeated attempts for invalid values. 
    //      Follow the format, including whitespaces, of the sample output EXACTLY.
    int tries;
    do{
        
        if (tries == 0){
        printf("Enter the value (1 or 2) for the initial active cell: ");
        }else{
        printf("Enter the value (1 or 2) for the initial active cell: ");
        }
        scanf("%d", &initialState);
        printf("\n");
        tries++;
    } while (initialState != 1 && initialState != 2);

    //printf("\n");
    //TODO: Task 5c - initialize the world with the ONLY non-zero cell in the 
    //      exact middle of the world, whose status value is set using the 
    //      scanned-in value from the user above. Make sure to also set the 
    //      localSum subitem for each cell of the initial world.
    //      Follow the format, including whitespaces, of the sample output EXACTLY.
    
    for (int i = 0; i< WORLD_SIZE; i++){
        world[i].status = 0;
        world[i].count = 0;
    }
    world[WORLD_SIZE/2].status = initialState;
    world[WORLD_SIZE/2].count = initialState;

    setSums(world);

    printf("\n");
    printf("Initializing world & evolving...");
    printf("\n");

    for (int i=0; i < WORLD_SIZE; i++){
        if(world[i].status == 2) {
           
            printf("+ ");
        } else if (world[i].status == 1){
            printf("- ");
        } else {
            printf(" ");
        }
    }

    printf("%d \n", initialState);


//TASK 7-print the world using the cell representation 
for (int genStep=1; genStep < numOfgen; genStep++){
    evolveWorld(world, valArray);

    for (int i=0; i<WORLD_SIZE; i++){
        if (world[i].status == 2){
            printf("+");
        }else if (world[i].status == 1){
            printf("-");
        }else{
            printf(" ");
        }
        
    }

    printf(" "); 
//Finds out the total active statuses
    int totalSum = 0;
    for (int i = 0; i <WORLD_SIZE; i++){
        totalSum += world[i].status;
    }

    printf("%d \n", totalSum);
}

printf("_________________________________________________________________\n");

//TASK 8 that prints and counts every cell

    for (int i=0; i <WORLD_SIZE; i++){
        if(world[i].count >=10){
            printf("%d", world[i].count/10);
        }else{
            printf(" ");
        }
    }
    printf("\n");

    for (int i=0; i<WORLD_SIZE; i++){
        if(world[i].count == 0){
            printf(" ");
        }else{
            printf("%d", world[i].count % 10);
        }
    }
    printf("\n"); // make sure to end your program with a newline
    return 0;
}